#ifndef BUSQUEDA_H_
#define BUSQUEDA_H_

#include "busqueda.h"
LISTA ordenarLista(LISTA Ab, LISTA q, int tipo);

#endif